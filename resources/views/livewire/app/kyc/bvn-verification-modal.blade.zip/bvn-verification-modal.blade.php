<div>
    @if($showModal)
        <div class="fixed inset-0 z-50 flex items-center justify-center">
            <!-- Backdrop -->
            <div class="absolute inset-0 bg-black/80 backdrop-blur-sm" wire:click="closeModal"></div>

            <!-- Modal Panel -->
            <div class="relative w-full max-w-md bg-gray-900 rounded-2xl shadow-xl border border-gray-800 p-6">

                @if($isCompleted)
                    <!-- Success View -->
                    <div class="text-center py-4">
                        <!-- Success Icon -->
                        <div
                            class="mx-auto w-20 h-20 bg-green-500/10 rounded-full flex items-center justify-center mb-6 ring-1 ring-green-500/30">
                            <i data-lucide="check" class="w-10 h-10 text-green-500"></i>
                        </div>

                        <h3 class="text-2xl font-bold text-white mb-2">Verification Successful!</h3>
                        <p class="text-gray-400 mb-8 text-sm">Your identity has been verified and your virtual account
                            is ready for use.</p>

                        <!-- Account Details Card -->
                        <div
                            class="bg-gray-800/50 rounded-xl p-6 space-y-5 border border-gray-700 text-left relative overflow-hidden">
                            <!-- Decorative background element -->
                            <div
                                class="absolute top-0 right-0 -mt-4 -mr-4 w-24 h-24 bg-[#E1B362]/10 rounded-full blur-2xl"></div>

                            <div>
                                <p class="text-xs text-gray-500 uppercase tracking-wider font-semibold mb-1">Bank
                                    Name</p>
                                <p class="text-white font-medium text-lg">{{ $createdAccountDetails['bankName'] ?? 'SafeHaven Bank' }}</p>
                            </div>

                            <div class="pt-4 border-t border-gray-700/50">
                                <p class="text-xs text-gray-500 uppercase tracking-wider font-semibold mb-1">Account
                                    Number</p>
                                <div class="flex items-center justify-between">
                                    <p class="text-[#E1B362] font-mono font-bold text-2xl tracking-widest">{{ $createdAccountDetails['accountNumber'] ?? 'N/A' }}</p>
                                </div>
                            </div>

                            <div class="pt-4 border-t border-gray-700/50">
                                <p class="text-xs text-gray-500 uppercase tracking-wider font-semibold mb-1">Account
                                    Name</p>
                                <p class="text-white font-medium text-lg truncate">{{ $createdAccountDetails['accountName'] ?? 'N/A' }}</p>
                            </div>
                        </div>

                        <button wire:click="closeModal"
                                class="mt-8 w-full py-3.5 bg-[#E1B362] hover:bg-orange-400 text-white rounded-lg font-bold transition-colors shadow-lg shadow-orange-500/20">
                            Done
                        </button>
                    </div>
                @else
                    <!-- Standard Flow -->
                    <div class="flex justify-between items-center mb-6">
                        <h3 class="text-xl font-bold text-white">Verify Your BVN</h3>
                        <button wire:click="closeModal" class="text-gray-400 hover:text-white transition">
                            <i data-lucide="x" class="w-5 h-5"></i>
                        </button>
                    </div>

                    <!-- Error Message -->
                    @if($errorMessage)
                        <div class="mb-4 p-4 bg-red-500/10 border border-red-500/30 rounded-lg">
                            <div class="flex items-center gap-2">
                                <i data-lucide="alert-circle" class="w-4 h-4 text-red-400"></i>
                                <p class="text-red-400 text-sm">{{ $errorMessage }}</p>
                            </div>
                        </div>
                    @endif

                    <!-- Intermediate Success Message (e.g. BVN Found) -->
                    @if ($successMessage)
                        <div class="mb-4 p-4 bg-green-500/10 border border-green-500/30 rounded-lg">
                            <div class="flex items-start gap-2">
                                <i data-lucide="check-circle" class="w-4 h-4 text-green-400 mt-0.5"></i>
                                <p class="text-green-400 text-sm whitespace-pre-line">{{ $successMessage }}</p>
                            </div>
                        </div>
                    @endif

                    @if (!$bvnInitiated)
                        <!-- BVN Entry Form -->
                        <form wire:submit.prevent="initiateBvnVerification" class="space-y-4">
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Bank Verification Number (BVN)</label>
                                <input wire:key="bvn-input" type="text" wire:model="bvn" maxlength="11"
                                       placeholder="Enter your 11-digit BVN"
                                       class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-[#E1B362] focus:ring-1 focus:ring-[#E1B362] outline-none transition">
                                @error('bvn')
                                <span class="text-red-500 text-sm mt-1">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="bg-blue-500/10 border border-blue-500/30 rounded-lg p-3">
                                <div class="flex items-start gap-2">
                                    <i data-lucide="info" class="w-4 h-4 text-blue-400 mt-0.5 flex-shrink-0"></i>
                                    <p class="text-xs text-blue-300">
                                        We'll verify your BVN and you'll need to confirm your phone number and date of
                                        birth.
                                    </p>
                                </div>
                            </div>

                            <button type="submit" wire:loading.attr="disabled" wire:target="initiateBvnVerification"
                                    class="w-full px-6 py-3 bg-[#E1B362] hover:bg-orange-400 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors">
                                                    <span wire:loading.remove wire:target="initiateBvnVerification">
                                                        Verify BVN
                                                    </span>
                                <span wire:loading wire:target="initiateBvnVerification"
                                      class="flex items-center justify-center gap-2">
                                                        <svg class="animate-spin h-4 w-4" viewBox="0 0 24 24">
                                                            <circle class="opacity-25" cx="12" cy="12" r="10"
                                                                    stroke="currentColor" stroke-width="4"
                                                                    fill="none"></circle>
                                                            <path class="opacity-75" fill="currentColor"
                                                                  d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z">
                                                            </path>
                                                        </svg>
                                                        Verifying...
                                                    </span>
                            </button>
                        </form>
                    @else
                        <!-- Confirmation Form -->
                        <form wire:submit.prevent="confirmAndComplete" class="space-y-4">
                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Phone Number</label>
                                <input wire:key="phone-input" type="tel" wire:model="phoneNumber"
                                       placeholder="08012345678" maxlength="11"
                                       class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-[#E1B362] focus:ring-1 focus:ring-[#E1B362] outline-none transition">
                                @error('phoneNumber')
                                <span class="text-red-500 text-sm mt-1">{{ $message }}</span>
                                @enderror
                                <p class="text-xs text-red-500 mt-1">HINT: Phone number ends with {{ $phoneSuffix }}</p>
                            </div>

                            <div>
                                <label class="block text-sm text-gray-400 mb-2">Date of Birth</label>
                                <input wire:key="dob-input" type="date" wire:model="dateOfBirth"
                                       max="{{ date('Y-m-d') }}" placeholder="1991-06-28"
                                       class="w-full bg-gray-800 border border-gray-700 rounded-lg px-4 py-3 text-white focus:border-[#E1B362] focus:ring-1 focus:ring-[#E1B362] outline-none transition">
                                @error('dateOfBirth')
                                <span class="text-red-500 text-sm mt-1">{{ $message }}</span>
                                @enderror
                            </div>

                            <div class="flex gap-3">
                                <button type="button" wire:click="resetBvnEntry"
                                        class="flex-1 px-6 py-3 bg-gray-800 hover:bg-gray-700 text-white rounded-lg font-medium transition-colors">
                                    Back
                                </button>
                                <button type="submit" wire:loading.attr="disabled" wire:target="confirmAndComplete"
                                        class="flex-1 px-6 py-3 bg-[#E1B362] hover:bg-orange-400 disabled:bg-gray-600 disabled:cursor-not-allowed text-white rounded-lg font-medium transition-colors">
                                                        <span wire:loading.remove wire:target="confirmAndComplete">
                                                            Submit
                                                        </span>
                                    <span wire:loading wire:target="confirmAndComplete"
                                          class="flex items-center justify-center gap-2">
                                                            <svg class="animate-spin h-4 w-4" viewBox="0 0 24 24">
                                                                <circle class="opacity-25" cx="12" cy="12" r="10"
                                                                        stroke="currentColor" stroke-width="4"
                                                                        fill="none"></circle>
                                                                <path class="opacity-75" fill="currentColor"
                                                                      d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z">
                                                                </path>
                                                            </svg>
                                                            Processing...
                                                        </span>
                                </button>
                            </div>
                        </form>
                    @endif
                @endif
            </div>
        </div>
    @endif
</div>
