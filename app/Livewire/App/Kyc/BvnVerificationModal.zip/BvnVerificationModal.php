<?php

declare(strict_types=1);

namespace App\Livewire\App\Kyc;

use App\Services\SafeHavenApi\AccountsService;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;
use Livewire\Component;

class BvnVerificationModal extends Component
{
    public bool $showModal = false;
    public string $bvn = '';
    public string $phoneNumber = '';
    public string $dateOfBirth = '';
    public bool $bvnInitiated = false;
    public bool $isLoading = false;
    public ?string $errorMessage = null;
    public ?string $successMessage = null;
    public ?string $phoneSuffix = null;
    public ?array $bvnData = null;

    // New properties for success state
    public bool $isCompleted = false;
    public array $createdAccountDetails = [];

    protected $listeners = ['openModal'];

    protected array $rules = [
        'bvn' => 'required|digits:11',
        'phoneNumber' => 'required|regex:/^0[789][01]\d{8}$/',
        'dateOfBirth' => 'required|date|before:today',
    ];

    protected array $messages = [
        'bvn.required' => 'BVN is required',
        'bvn.digits' => 'BVN must be exactly 11 digits',
        'phoneNumber.required' => 'Phone number is required',
        'phoneNumber.regex' => 'Please enter a valid Nigerian phone number',
        'dateOfBirth.required' => 'Date of birth is required',
        'dateOfBirth.date' => 'Please enter a valid date',
        'dateOfBirth.before' => 'Date of birth must be in the past',
    ];

    public function initiateBvnVerification(): void
    {
        $this->validate(['bvn' => 'required|digits:11']);

        $this->isLoading = true;
        $this->errorMessage = null;
        $this->successMessage = null;

        Log::info('BVN Initiated', [
            'BVN' => $this->bvn,
        ]);

        try {
            $safeHavenService = app(AccountsService::class);
            $response = $safeHavenService->initiateBvnVerification($this->bvn);

            if ($response['status'] === 200 && isset($response['json']['message'])) {
                preg_match('/ending with (\d{4})/', $response['json']['message'], $matches);
                $this->phoneSuffix = $matches[1] ?? null;

                if ($this->phoneSuffix) {
                    $this->bvnInitiated = true;
                    $this->bvnData = $response['data'] ?? [];
                    $this->successMessage = "BVN found! Please confirm your phone number ending with {$this->phoneSuffix} and date of birth.";
                } else {
                    $this->errorMessage = 'Unable to extract phone number information. Please try again.';
                }
            } else {
                $this->errorMessage = $response['message'] ?? 'Failed to verify BVN. Please check the number and try again.';
            }
        } catch (\Exception $e) {
            Log::error('BVN Verification Initiation Error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'user_id' => auth()->id(),
                'bvn' => substr($this->bvn, 0, 3).'********',
            ]);

            $this->errorMessage = 'An error occurred while verifying BVN. Please try again later.';
        } finally {
            $this->isLoading = false;
        }
    }

    public function confirmAndComplete(): void
    {
        Log::info('SUBACCOUNT PAYLOAD', [
            'BVN' => $this->bvn,
            'Phone Number' => $this->phoneNumber,
            'Date of Birth' => $this->dateOfBirth,
        ]);

        $this->validate([
            'phoneNumber' => 'required|regex:/^0[789][01]\d{8}$/',
            'dateOfBirth' => 'required|date|before:today',
        ]);

        $this->isLoading = true;
        $this->errorMessage = null;

        try {
            $enteredSuffix = substr($this->phoneNumber, -4);
            if ($enteredSuffix !== $this->phoneSuffix) {
                $this->errorMessage = "Phone number doesn't match the one linked to your BVN (ending with {$this->phoneSuffix})";
                $this->isLoading = false;
                return;
            }

            $this->createdAccountDetails = DB::transaction(function () {
                $user = auth()->user();

                $payload = [
                    'email' => $user->email,
                    'phone' => $this->phoneNumber,
                    'externalReference' => rand(1000000000, 9999999999).'_'.time(),
                    'identityNumber' => $this->bvn,
                    'dateOfBirth' => $this->dateOfBirth,
                    'booleanMatch' => true,
                ];

                Log::info('Creating Safe Haven Sub Account with payload', [
                    'payload' => $payload,
                    'user_id' => $user->id,
                ]);

                $safeHavenService = app(AccountsService::class);
                $response = $safeHavenService->createSafeHavenSubAccount($payload);
                if ($response['status'] !== 200) {
                    throw new \Exception('Failed to create Bank Account: '.($response['json']['message'] ?? 'Unknown error'));
                }

                $user->update([
                    'bvn' => $this->bvn,
                    'dob' => $this->dateOfBirth,
                ]);

                $user->virtualBankAccount()->updateOrCreate(
                    ['user_id' => $user->id],
                    [
                        'account_name' => $response['json']['data']['accountName'] ?? null,
                        'account_number' => $response['json']['data']['accountNumber'] ?? null,
                        'bank_name' => 'SafeHaven Bank',
                        'is_active' => 1,
                    ]
                );

                Log::info('Account Creation Completed', [
                    'user_id' => $user->id,
                    'sub_account_response' => $response,
                ]);

                return [
                    'bankName' => 'SafeHaven Bank',
                    'accountNumber' => $response['json']['data']['accountNumber'] ?? 'N/A',
                    'accountName' => $response['json']['data']['accountName'] ?? 'N/A',
                ];
            });

            // Mark as completed to switch UI
            $this->isCompleted = true;
            $this->dispatch('bvnVerified');

            // Note: Removed closeModalAfterDelay to allow user to read details
        } catch (\Exception $e) {
            Log::error('BVN Verification Completion Error', [
                'error' => $e->getMessage(),
                'trace' => $e->getTraceAsString(),
                'user_id' => auth()->id(),
            ]);

            $this->errorMessage = $e->getMessage();
        } finally {
            $this->isLoading = false;
        }
    }

    public function resetBvnEntry(): void
    {
        $this->bvnInitiated = false;
        $this->phoneSuffix = null;
        $this->bvnData = null;
        $this->phoneNumber = '';
        $this->dateOfBirth = '';
        $this->successMessage = null;
        $this->errorMessage = null;
    }

    public function openModal(): void
    {
        $this->resetState();
        $this->showModal = true;
    }

    public function closeModal(): void
    {
        $this->resetState();
        $this->showModal = false;
    }

    private function resetState(): void
    {
        $this->bvn = '';
        $this->phoneNumber = '';
        $this->dateOfBirth = '';
        $this->bvnInitiated = false;
        $this->errorMessage = null;
        $this->successMessage = null;
        $this->phoneSuffix = null;
        $this->bvnData = null;
        $this->isLoading = false;
        $this->isCompleted = false;
        $this->createdAccountDetails = [];
    }

    public function render()
    {
        return view('livewire.app.kyc.bvn-verification-modal');
    }
}
